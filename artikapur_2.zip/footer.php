<section class="footer">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <center>
          <p>Mumbai, Maharashtra</p>
          
          <p><span class="flaticon-technology"></span>: (208) 333 9296</p>
          <p><span class="flaticon-e-mail-envelope"></span>: artikapur02@gmail.com</p>
          <hr>
                      <div class="follow">
                <ul>
                    <li><a href="#"><i class="fa fa-facebook my-icon" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter my-icon2" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin my-icon4" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus my-icon3" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </center>
      </div>
    </div>
  </div>
</section>
<div class="footer-bottom end">
    <center>
        <p>© 2019 Artikapur Interior Designer | All Rights Reserved</p>
      </center>
</div>


<!--Scroll to top-->
<!-- <div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div> -->

<!-- main jQuery -->
<script src="js/jquery-1.11.1.min.js"></script>
<!-- bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- bx slider -->
<script src="js/jquery.bxslider.min.js"></script>
<!-- count to -->
<script src="js/jquery.countTo.js"></script>
<!-- owl carousel -->
<script src="js/owl.carousel.min.js"></script>
<!-- validate -->
<script src="js/validate.js"></script>
<!-- mixit up -->
<script src="js/jquery.mixitup.min.js"></script>
<!-- easing -->
<script src="js/jquery.easing.min.js"></script>
<!-- gmap helper -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAHzPSV2jshbjI8fqnC_C4L08ffnj5EN3A"></script>
<!--gmap script-->
<script src="js/gmaps.js"></script>
<script src="js/map-helper.js"></script>
<!-- video responsive script -->
<script src="js/jquery.fitvids.js"></script>
<!-- jQuery ui js -->
<script src="assets/jquery-ui-1.11.4/jquery-ui.js"></script>
<!-- Language Switche  -->
<script src="assets/language-switcher/jquery.polyglot.language.switcher.js"></script>
<!-- fancy box -->
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.appear.js"></script>
<!-- isotope script-->
<script src="js/isotope.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>            

<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>


<!-- thm custom script -->
<script src="js/custom.js"></script>

<script>
    $(document).ready(function(){
    $('.customer-logos').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 4
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 3
            }
        }]
    });
});
</script>




</body>

</html>