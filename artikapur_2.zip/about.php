<?php
    include_once('header.php');
?>

<div class="abbanner">
	<img src="images/ab_banner.jpg" class="img-responsive">
</div>

<!--Start welcome area-->
<section class="welcome-area">
    <div class="container clearfix">
        
        <div class="row">

            <div class="col-md-7 col-sm-12 col-xs-12">
                <div class="sec-title">
                    <h5>ABOUT COMPANY</h5>
                    <h2>A SMALL EFFICIENT <br>INTERIOR<span> DESIGNING TEAM</span></h2>
                </div>
                <div class="text-holder">
                    <!-- <h3>We are the best Interior designer since 1975.</h3> -->
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                    
                </div>
            </div>
            <div class="col-md-5 col-sm-12 col-xs-12">
                <div class="gallery">
                    <img src="images/main-abt.jpg" class="img-responsive">
                </div>
            </div>
            
        </div>
    </div>
</section>

<?php
    include_once('footer.php');
?>