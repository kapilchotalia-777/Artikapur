<?php
    include_once('header.php');
?>

<div class="abbanner">
	<img src="images/ab_banner.jpg" class="img-responsive">
</div>


<div class="videopg">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div align="center" class="embed-responsive embed-responsive-16by9">
				    <video id="video" class="video-playing"  controls>
				      <source src="images/video/VID-20190714-WA0004.mp4">
				      </video>
				</div>
			</div>

			<div class="col-md-4">
				<div align="center" class="embed-responsive embed-responsive-16by9">
				    <video id="video" class="video-playing"  controls>
				      <source src="images/video/VID-20190727-WA0051.mp4">
				      </video>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
    include_once('footer.php');
?>
